var texto = "Mensagem de modulo";
module.exports = texto;