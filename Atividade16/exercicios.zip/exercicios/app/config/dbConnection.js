var sql = require ('mssql/msnodesqlv8'); 
module.exports = function(){ 
 
 const config = { 
 user: 'BD2013004', 
 password: 'Naco8246555', 
 database: 'BD', //your database 
 server: '192.168.1.6', 
 driver: 'msnodesqlv8', 
 } 
 return sql.connect(config); 
} 
